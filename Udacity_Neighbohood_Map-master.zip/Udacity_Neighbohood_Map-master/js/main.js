var puneMap;

function initPuneMap() {
    // Constructor to create a new puneMap JS object.
    //18.520278,73.856667 - Pune, Maharashtra, India
    puneMap = new google.maps.Map(document.getElementById('puneMap'), {
        center: {
            lat: 18.520278,
            lng: 73.856667
        },
        zoom: 12
    });

    // Location function used for marker.
	var PuneLocationFn = function(data) {
        var self = this;
        this.title = data.title;
        this.lng = data.lng;
        this.lat = data.lat;
        this.venueId = data.venueId;
        this.cat = data.cat;
		// By default every marker will be visible
		this.visible = ko.observable(true);
		
        // getInfoContent function retrieves 6 most recent tips from foursquare for the marker location.
        this.getInfoContent = function() {
            var recentTips = [];
            var locationUrl = 'https://api.foursquare.com/v2/venues/' + self.venueId + '/tips?sort=recent&v=20171231&client_id=00VC4PHYI0J1B4FIREFGUH3W3HHES1PJDNGG2RANW044C2UG&client_secret=WGTMUYZXF2DWFKAZGZS0JMK5QDOGP43VSQKRO4D310EPQQQW';

            $.getJSON(locationUrl,
                function(data) {
                    $.each(data.response.tips.items, function(i, tips) {
                        if (i < 4) {
                            if (tips.type == 'user') {
                                recentTips.push('<li>' + tips.text + ' -- <b>' + tips.user.firstName + '</b></li>');
                            } else {
                                recentTips.push('<li>' + tips.text + '</li>');
                            }
                        }
                    });

                }).done(function() {

                self.content = '<h2>' + self.title + '</h2>' + '<h3>Most Recent Tips</h3>';
                self.content += '<ol class="tips">' + recentTips.join('') + '</ol>';

            }).fail(function(jqXHR, textStatus, errorThrown) {
                self.content = '<h2>' + self.title + '</h2><h4>Oops. There was a problem retrieving this location\'s tips.</h4>';
            });
        }();

        // Info window details
        this.infowindowDetails = new google.maps.InfoWindow();

        // Marker icon.
        switch (this.cat) {
            case "Cinema Theater":
                this.icon = 'http://www.googlemapsmarkers.com/v1/T/009900/';
                break;
            case "Hotel":
                this.icon = 'http://www.googlemapsmarkers.com/v1/H/0099FF/';
                break;
            case "Fort":
                this.icon = 'http://www.googlemapsmarkers.com/v1/F/FCBE2C/';
                break;    
            case "Park":
                this.icon = 'http://www.googlemapsmarkers.com/v1/P/FCBE2C/';
                break;
            default:
                this.icon = 'http://www.googlemapsmarkers.com/v1/D/990000/';
        }
        this.marker = new google.maps.Marker({
            position: new google.maps.LatLng(self.lng, self.lat),
            puneMap: puneMap,
            title: self.title,
            icon: self.icon,
            animation: google.maps.Animation.DROP
        });
		
		//Display function for marker
		this.showMarker = ko.computed(function() {
			if(this.visible() === true) {
				this.marker.setMap(puneMap);
			} else {
				this.marker.setMap(null);
			}
			return true;
		}, this);

        // Opens the info window for the location marker.
        this.openInfowindow = function() {
            for (var i = 0; i < puneLocationModel.puneLocations.length; i++) {
                puneLocationModel.puneLocations[i].infowindowDetails.close();
            }
            puneMap.panTo(self.marker.getPosition());

            //Setting content in puneMap popup
            self.infowindowDetails.setContent(self.content);
            self.infowindowDetails.open(puneMap, self.marker);
			
			//Animate the selected marker
			self.marker.setAnimation(google.maps.Animation.BOUNCE);
			setTimeout(function() {
				self.marker.setAnimation(null);
			}, 2100);
        };
		
		// Animate whenever we clicking the marker
		this.bounce = function(place) {
			google.maps.event.trigger(self.marker, 'click');
		};

        // Assigns the click event for marker
        this.addListener = google.maps.event.addListener(self.marker, 'click', (this.openInfowindow));
    };

    // Location model
	let tempPuneLocations = [{
			title: 'Rahul-70MM',
			lng: 18.5315026, 
			lat: 73.8464694,
			venueId: '4ba5a8a1f964a520fb1939e3',
			cat:'Cinema Theater'
		},{
			title: 'City Pride-Abhiruchi',
			lng: 18.4629,
			lat: 73.8164,
			venueId: '4ec4aa7c4690b682a3e416ca',
			cat:'Cinema Theater'
		},{
			title: 'Sinhgad Fort',
			lng: 18.3565,
			lat: 73.7507,
			venueId: '4c45db36f05e95213b86e4b3',
			cat: 'Fort'
		},{
			title: 'P L Deshpande',
			lng: 18.4933,
			lat: 73.8354,
			venueId: '4d325922329e548167e5af1d',
			cat: 'Park'
		},{
			title: 'Hyatt Hotel',
			lng: 18.5539,
			lat: 73.9036,
			venueId: '52cc6fa811d2abfb027c5885',
			cat:'Hotel'
		},{
			title: 'Vaishali Retaurant',
			lng: 18.520871,
			lat: 73.8412643,
			venueId: '4b3b174af964a520cd7025e3',
			cat:'Hotel'
		}
	];
	
	
	var locationsArr = [];
	for(let i=0; i<tempPuneLocations.length; i++){
		locationsArr.push(new PuneLocationFn(tempPuneLocations[i]));
	}
	var puneLocationModel = {
		puneLocations : locationsArr,
		query: ko.observable('')
	};

    puneLocationModel.availablePlaces = ko.computed(function() {
        var self = this;
        return ko.utils.arrayFilter(self.puneLocations, function(location) {
            return location.title.toLowerCase();
        });
    }, puneLocationModel);

    // Search function for filtering
    puneLocationModel.search = ko.computed(function() {
        var self = this;
		var filter = this.query().toLowerCase();
		if (!filter) {
            self.puneLocations.forEach(function(locationItem) {
                locationItem.visible(true);
            });
            return self.puneLocations;
        } else {
            return ko.utils.arrayFilter(self.puneLocations, function(locationItem) {
                var string = locationItem.title.toLowerCase();
                var result = (string.search(filter) >= 0);
                locationItem.visible(result);
                return result;
            });
        }
    }, puneLocationModel);

    ko.applyBindings(puneLocationModel);
}

function mapError() {
    $('#puneMap').html('<span class="errorMsg">Sorry, some issue with puneMap.</span>');
}

function openNav() {
    document.getElementById("mySideNavBar").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySideNavBar").style.width = "0";
}